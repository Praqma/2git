package migration

import net.praqma.clearcase.ucm.entities.Baseline as CoolBaseline

class Baseline {
    CoolBaseline source
    List<Action> actions = []
    HashMap<String, Object> extractions = []
}
