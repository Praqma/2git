package migration

import git.Git

class ActionsContext {
    List<Action> actions = []

    def void git(String cmd) {
        actions.add(new Action() {
            @Override
            void run() {
                Git.call(cmd)
            }
        })
    }
}
