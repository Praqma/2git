package migration

abstract class Action implements Runnable {
}
