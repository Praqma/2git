migrate('E:\\cc-to-git') {
    vob('\\2Cool_PVOB') {
        component('Model') {
            stream('model_int') {
                /*options { //????
                    git {
                        ignore ".jnk", ".log", ".bkp"
                    }
                } */
                migrationSteps {
                    filter {
                        criteria {
                            baselineName 'v.*'
                        }
                        extractions {
                            baselineExtractor([name: 'fqname']) //TODO ehh...
                            /*fileExtractor {

                            } */
                        }
                        actions {
                            git 'commit -m\"$name\"' //TODO pray
                            /*git {
                                commit {
                                    message name
                                    author user
                                }
                            }
                            log {
                                info "Committed {}", name
                            }*/
                        }
                    }
                    filter {
                        criteria {
                            promotionLevels 'TESTED', 'RELEASED'
                        }
                        extractions {

                        }
                        actions {
                            /*git {
                                tag name
                            }
                            log {
                                info "Tagged {}", name
                            } */
                        }
                    }

                }
            }
        }
    }
}